sub do_cmd_vpageref {
    &do_cmd_pageref;
}

1;                              # This must be the last line
