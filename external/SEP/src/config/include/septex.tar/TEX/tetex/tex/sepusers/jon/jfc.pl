package sep;

$LIB = '../Lib';
$OPS = '../Lib/book';

package main;

&process_commands_in_tex (<<_RAW_ARG_CMDS_);
_RAW_ARG_CMDS_

&ignore_commands( <<_IGNORED_CMDS_);
sx # {}
LIB 
_IGNORED_CMDS_

sub do_env_exer {
    local ($text) = @_;
    "<H2 align=left>EXERCISES:<\/H2>\n" . &list_helper($text,'OL');
}

sub do_cmd_bx {
    local ($_) = @_;
    s/$next_pair_pr_rx//o; 
    join ('','<B>',$2,'</B>',$_);
}

sub do_cmd_bxbx {
    local ($_) = @_;
    s/$next_pair_pr_rx//o;
    local ($word) = $2;
    s/$next_pair_pr_rx//o;
    join ('','<B>',$word,'</B>',$_);
}

sub do_cmd_progdex {
    local ($_) = @_;
    s/$next_pair_pr_rx//o; 
    local ($prog) = $2;
    s/$next_pair_pr_rx//o;  
    join(' ',
	 &anchor_label("_prog:".$prog,$CURRENT_FILE,''), 
	 &sep::verb_input (join('/',$sep::pathname,$sep::LIB,"$prog.rt")),
	 $_);
}

sub do_cmd_opdex {
    local ($_) = @_;
    s/$next_pair_pr_rx//o; 
    local ($prog) = $2;
    s/$next_pair_pr_rx//o;  
    join(' ',
	 &anchor_label("_prog:".$prog,$CURRENT_FILE,''), 
	 &sep::verb_input (join('/',$sep::pathname,$sep::OPS,"$prog.lop")),
	 $_);
}

sub do_cmd_moddex {
    local ($_) = @_;
    s/$next_pair_pr_rx//o; 
    local ($prog) = $2;
    s/$next_pair_pr_rx//o;  
    join(' ',
	 &anchor_label("_prog:".$prog,$CURRENT_FILE,''), 
	 &sep::verb_input (join('/',$sep::pathname,$sep::OPS,"$prog.r90")),
	 $_);
}

sub do_cmd_todo {
    local($_) = @_;
    s/$next_pair_pr_rx//o; 
    print STDERR "**************\n$_\n------------------\n";
    print STDERR "**************\n$2\n------------------\n";
}

1;                              # This must be the last line





