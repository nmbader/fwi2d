package sep;

$pathname = "..";

sub verb_input {
    my $file = shift;
    local ($out,$_);
    if (-f $file) {
	if (open (SEPINPUT, $file)) {
	    print "Opened $file...\n";
	    $out = join ($codecolor,"<FONT COLOR=\"","\"><PRE>\n");
	    while (<SEPINPUT>) {
		# pre_process file contents
		&main::replace_html_special_chars;
		$out .= $_;
	    }
	    $out .= "<\/PRE><\/FONT>\n";
	    close (SEPINPUT);
	} else {
	    print "Couldn't open $file\n";
	}
    } else {
	print "File $file is not found\n";
    }    
    $out;
}

package main;

&ignore_commands( <<_IGNORED_CMDS_);
FloatListing
NoFloatListing
_IGNORED_CMDS_

sub do_cmd_inputdir {
    my $rest = shift;
    $rest =~ s/$next_pair_pr_rx//o;
    $sep::pathname = $2;
    $latex_body .= &revert_to_raw_tex("\\inputdir{$2}\n");
    $rest;
}
  
sub do_cmd_sepverbinput {
    my $rest = shift;
    $rest =~ s/$next_pair_pr_rx//o;
    my $name = $2;
    if ($name =~ /\.tex$/) {
       join ('',"<A HREF=\"..\/",$name,"\">",$name,"<\/A>\n",$rest);
    } else {
	my $file = join ('/', $sep::pathname, $name);
        &sep::verb_input ($file) . $rest;
    }
}

sub do_cmd_listing {
    &do_cmd_sepverbinput;
}

sub do_cmd_gprog {
    local ($_) = @_;
    s/$next_pair_pr_rx//o;
    my $label = $2; # do something with it!
    s/$next_pair_pr_rx//o;
    my $file = "$sep::pathname/$2";
    s/$next_pair_pr_rx//o;
    join ('',&sep::verb_input ($file),"<BR>",$2,"<BR>", $_);
}

sub do_cmd_prog {
    local ($_) = @_;
    s/$next_pair_pr_rx//o;
    my $label = $2; # do something with it!
    s/$next_pair_pr_rx//o;
    my $file = "$sep::pathname/$2";
    s/$next_pair_pr_rx//o;
    join ('',&sep::verb_input ($file),"<BR>",$2,"<BR>", $_);
}

sub do_cmd_progblock {
    local ($_) = @_;
    s/$next_pair_pr_rx//o;
    my $label = 'prog:' . $2; 
    s/$next_pair_pr_rx//o;
    join(' ',
	 &anchor_label($label,$CURRENT_FILE,''),
	 &sep::verb_input ("$sep::pathname/$2"),
	 $_);
}

sub do_cmd_gprogblock {
    local ($_) = @_;
    s/$next_pair_pr_rx//o;
    my $label = $2; # do something with it!
    s/$next_pair_pr_rx//o;
    &sep::verb_input ("$sep::pathname/$2") . $_;
}

1;                              # This must be the last line

