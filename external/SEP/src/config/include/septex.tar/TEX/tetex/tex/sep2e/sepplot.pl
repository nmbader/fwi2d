# Hector Urdaneta  (HU): 
#     Changed 'fig' to 'fig:' for $label for all do_cmd_...plot()
#     Moved &anchor_label to the beginning of every join(), before
#     the &sep::figure call, for all do_cmd_...plot()
#
package sep;

$star = 'http://sepwww.stanford.edu/sep/sergey/small_star.gif'; 
$fignum = 0; 
$blinker = 'http://sepwww.stanford.edu/our/cgi-bin/sergey/blinker.pl'; 

sub figure {
    my ($figname,$size) = @_;
    print "Translating plot $figname...\n"; 
    my $out = join ('', "<TD><IMG SRC = \"",
			 $gifdir,$figname,".gif\"");
    foreach $dimension ("width","height") {
	if ($size =~ /$dimension=(\d*\.?\d*)in/) {
	    $out .= sprintf (" %s=%d",$dimension,$1*75);
	} elsif ($size =~ /$dimension=(\d*\.?\d*)cm/) {
	    $out .= sprintf (" %s=%d",$dimension,$1*30);
	}
	
    }
    $out .= " ALT = \"$figname\"><\/TD>";
} 

sub caption {
    my ($figname,$caption) = @_;
    join ('',"<STRONG>","<A HREF = \"..\/Gif\/$figname.gif\">$figname<\/A>",
	  "<BR>Figure ",$fignum,"<\/STRONG> ",$caption);
}

sub buttons {
    my ($figname,$repr) = @_;
    my ($string,@buttons);
    if      ($repr =~ /^ER/) {
	@buttons = ("view","burn","build","edit","restore");
    } elsif ($repr =~ /^CR/) {
	@buttons = ("view","warning","burn","build","edit","restore");
    } elsif ($repr =~ /^NR/) {
	@buttons = ("view"); 
    }
    if ($repr =~ /M$/) {
	$string = join ('',"<A HREF=\"",$blinker,"\/++\/Gif\/",
			$figname,"\/\">",
			&main::img_tag ($main::icons {"movie_mark"}),
			"<\/A> ");
    }
    foreach $btn (@buttons) {
	$string = join (" ", $string, &makebutton ($gifdir,$figname,$btn)); 
    }
    $string;
}

package main;

&ignore_commands( <<_IGNORED_CMDS_);
psfigs
SYSCALL # {} # {}
iex     # {} # {}
notinteractive
interactive
noshowiex
showiex
noIdocMenu
_IGNORED_CMDS_

sub do_cmd_DOT {
   my $text = shift;
   join ('','.',$text);
}

sub do_cmd_plotbox {
    my $text = shift;
    $sep::fignum++;
    $text =~ s/$next_pair_pr_rx//o; my $figname = $2;
    $text =~ s/$next_pair_pr_rx//o; my $size    = $2;
    join ("\n","<P><CENTER>","<TABLE BORDER>",
	  &sep::figure ($figname,$size),
          "<\/TABLE>","<\/CENTER><\/P>",$text);
}

sub do_cmd_activeplot {
    local ($_) = @_;    
    &get_next_optional_argument;
    $sep::fignum++;
    my ($figname, $size, $repr, $caption);
    foreach $arg ($figname, $size, $repr, $caption) {
	s/$next_pair_pr_rx//o;
	$arg = $2;
    }
    # HU: Changed 'fig' for 'fig:'
    my $label = 'fig:' . $figname;
    # HU: Moved &anchor_label to the top of the command. Otherwise
    #     the link does not point to the right place.
    join ("\n","<P><CENTER>",
	  &anchor_label($label,$CURRENT_FILE,''),
	  "<TABLE BORDER>",
	  &sep::figure  ($figname,$size),"<\/TABLE>",
          &sep::caption ($figname,$caption),"<BR>",
          &sep::buttons ($figname,$repr),"<\/CENTER><\/P>", $_);
}

sub do_cmd_plot {
    local ($_) = @_;
    &get_next_optional_argument;
    $sep::fignum++;
    my ($figname, $size, $caption);
    foreach $arg ($figname, $size, $caption) {
	s/$next_pair_pr_rx//o;
	$arg = $2;
    }
    my $label = 'fig:' . $figname;
    join ("\n","<P><CENTER>",
          &anchor_label($label,$CURRENT_FILE,''),
	  "<TABLE BORDER>",
	  &sep::figure  ($figname,$size),"<\/TABLE>",
          &sep::caption ($figname,$caption),"<BR><\/CENTER><\/P>", $_);
}

sub do_cmd_activesideplot {
    local ($_) = @_;
    &get_next_optional_argument;
    $sep::fignum++;
    my ($figname, $size, $repr, $caption);
    foreach $arg ($figname, $size, $repr, $caption) {
	s/$next_pair_pr_rx//o;
	$arg = $2;
    }
    my $label = 'fig:' . $figname;
    join ("\n","<P><CENTER>",
	  &anchor_label($label,$CURRENT_FILE,''), 
	  "<TABLE BORDER=0>","<TR>",
	  "<TD WIDTH=\"40\%\">",
	  &sep::caption ($figname,$caption),"<\TD>",
	  &sep::figure  ($figname,$size),"<\/TABLE>",
          &sep::buttons ($figname,$repr),"<\/CENTER><\/P>", $_);
}

sub do_cmd_sideplot {
    local ($_) = @_;
    &get_next_optional_argument;
    $sep::fignum++;
    my ($figname, $size, $caption);
    foreach $arg ($figname, $size, $caption) {
	s/$next_pair_pr_rx//o;
	$arg = $2;
    }
    my $label = 'fig:' . $figname;
    join ("\n","<P><CENTER>",
	  &anchor_label($label,$CURRENT_FILE,''),
	  "<TABLE BORDER=0>","<TR>",
	  "<TD WIDTH=\"40\%\">",
	  &sep::caption ($figname,$caption),"<\TD>",
	  &sep::figure  ($figname,$size),
          "<\/TABLE><\/CENTER><\/P>", $_);
}


sub do_cmd_bioplot {
    my $text = shift;
    my ($figname, $size, $repr, $caption);
    foreach $arg ($figname, $size, $repr, $caption) {
	$text =~ s/$next_pair_pr_rx//o;
	$arg = $2;
    }
    join ("\n","<P><CENTER>","<TABLE BORDER=0>","<TR>",
	  "<TD WIDTH=\"71\%\">",
	  &sep::caption ($figname,$caption),"<\TD>",
	  &sep::figure  ($figname,$size),"<\/TABLE>",
	  "<\/CENTER><\/P>",$text);
}

sub do_cmd_syscall {
    my $text = shift;
    $text =~ s/$next_pair_pr_rx//o;
    my $call = $2;
    join ('','<A HREF=\"',$sep::gifdir,$call,'.sepsh\">make ',$call,
	  '</A> <IMG SRC=',$sep::star,">\n",$text);
}

1;                              # This must be the last line
