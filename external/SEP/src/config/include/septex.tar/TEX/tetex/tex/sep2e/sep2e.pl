package sep;

$article = 1;
$chaptername = '';
@emailaddress = "Author has no known email address";
#@metakeywords = " ";

sub checkAbs {
    my $html = shift;
    local ($_, $in, $abs);
    open (HTML, $html) or return '';
    while (<HTML>) {
	last if ($in && /^(\<P\>)?\<\/TD\>/);
	if (/^\<TD\>/) {
	    $_ = <HTML>;
	    $in = /^\<H1 ALIGN=CENTER\>ABSTRACT\<\/H1\>/; 
	} elsif ($in) {
	    s/\<P\>//g;
	    s/(SRC\=\")/join('',$1,$paper,"\/paper_html\/")/eg;
	    s/(HREF\=\")/join('',$1,$paper,"\/paper_html\/")/eg;
	    $abs .= $_ if (/\S/);  
	}
    }
    close (html);
    $abs;
}

sub checkIntro {
    my $html = shift;
    local ($_,$in, $abs);
    open (HTML, $html) or return ''; 
    my @lines = <HTML>;
    foreach (@lines) {
	if ($in > 10) {
	    last unless (/\s+(ALT|SRC|HREF)=/);
	}
	if (/^\<\/H1\>/ ) {
	    $in = 1;  
	} elsif ($in) {
	    $in++;
	    s/\<P\>//g;
	    s/(SRC\=\"([^h]))/join('',$1,$paper,"\/paper_html\/",$2)/eg;
	    s/(HREF\=\")/join('',$1,$paper,"\/paper_html\/")/eg;
	    $abs .= $_ if (/\S/);
	}
    }
    $abs =~ s/<[^\\>]+>\s$/ /;
    close (html);
    $abs .= ' ...' if ($abs);
}

sub checkToc {
    my $html = shift;
    local ($_, $in, $abs);
    open (html, $html . 'node1.html') or return ''; 
    while (<html>) {
	$in-- if (/^\<\!--End of Table of Child-Links/);
	if ($in) {
	    s/HREF=\"/HREF=\"$html/;
	    $abs .= $_;
	}
	$in++ if (/^\<A NAME=\"CHILD_LINKS/);
    }
    close (html);
    $abs;
}

sub getAbs {
    local $paper = shift;
    &checkAbs         ($paper . '/paper_html/index.html') or 
	&checkIntro   ($paper . '/paper_html/node1.html') or
	    &checkToc ($paper . '/paper_html/');   
}


package main;

$TITLE = "";

&process_commands_in_tex (<<_RAW_ARG_CMDS_);
appendix 
appendname # {}
_RAW_ARG_CMDS_

&ignore_commands( <<_IGNORED_CMDS_);
keywords # {}
nokeywords
footer # {}
header # {}
sephead # {}
SEPheader # {}
REPORT
afterpreface 
principaladviser # {} 
beforepreface 
tableofcontents
firstreader # {}
dept # {} 
secondreader # {}
thirdreader # {}
copyrightyear # {}
cleardoublepage
_IGNORED_CMDS_

sub do_cmd_SEPpaper {
    local ($_) = @_;
    s/$next_pair_pr_rx//o;
    $sep::fignum = 0;
    $sep::chaptername = $2 .'_';
    $_;
}

sub do_cmd_TOCentry {
    local ($_) = @_;
    my ($author,$title) =  &get_next_optional_argument;
    my (@dirs,$html);
    s/$next_pair_pr_rx//o; 
    $title = $2;
    s/$next_pair_pr_rx//o;
    $paper = $2;
    if ($author) {
	$paper =~ s/^[^\#]+\#([^\#]+)(\.start)\#.*$/$1/;
	$paper = '../' . $paper;
	if ($author eq "same") {
	    $author = '';
	    $html = ($paper =~ /(intro|preface)/)?
		$paper . '_html/node1.html' : 
		    $paper . '/paper_html/node1.html';
	} else {
	    $html = $paper . '/paper_html/index.html';
	} 
	my $ps   = $paper . '.ps.gz';
	my $pd   = $paper . '.pdf';
	my $tr   = $paper . '.tar.gz';
	my $abs = sep::getAbs ($paper);
        my $pssize = (stat($ps)) [7];
	my $pdsize = (stat($pd)) [7];
        my $trsize = (stat($tr)) [7];
        $pssize = int ($pssize/1024);
	$pdsize = int ($pdsize/1024);
        $trsize = int ($trsize/1024);
        $author = "<BR>" . join($author,"<B>","<\/B>") if ($author);
	$author = join('',"(<A HREF=\"",$tr,"\">src ",$trsize,"K</A>)",$author) if $trsize;
	$abs = join($abs,"<BR><SMALL>","<\/SMALL>") if $abs;
	join (" ",
	      join('',"<A HREF=\"",$html,"\">",$title,"</A>"),
	      join('',"(<A HREF=\"",$ps,"\">ps.gz ", $pssize,"K</A>)"),
	      join('',"(<A HREF=\"",$pd,"\">pdf ", $pdsize,"K</A>)"),
	      $author, $abs,"<BR>",$_);
    } else {
	print "title $title?\n";
	$_;
    }
}

sub do_cmd_bold {
    my $text = shift; 
    $text =~ s/$next_pair_pr_rx//o;
    join ('',"<B>",$2,"<\/B>",$text);
}

sub do_cmd_sepreport {
    local ($_) = @_;
    $sep::article = 1;
    $_;
}

sub do_cmd_shortnote {
    local ($_) = @_;
    $sep::article = 0;
    $_;
}

sub do_cmd_righthead {
    my $rest = shift;
    $rest =~ s/$next_pair_rx//o unless ($rest =~ s/$next_pair_pr_rx//o);
    local ($_) = $2;
    &extract_pure_text("liberal");
    $TITLE .= $_;
    $rest;
}

sub do_cmd_lefthead {
    my $rest = shift;
    $rest =~ s/$next_pair_rx//o unless ($rest =~ s/$next_pair_pr_rx//o);
    local ($_) = $2;
    &extract_pure_text("liberal");
    $TITLE = join (": ",$_,$TITLE);
    $rest;
}

sub do_cmd_email {
    my $rest = shift;
    $rest =~ s/$next_pair_rx//o unless ($rest =~ s/$next_pair_pr_rx//o);
    my $email = $2;
    $email =~ s/\band//;
    @sep::emailaddress = grep (/\@/, split (/([\,\;]\s*|\s+|\n)/,$email));
    $rest;
}

#sub do_cmd_keywords {
#    my $rest = shift;
#    $rest =~ s/$next_pair_rx//o unless ($rest =~ s/$next_pair_pr_rx//o);
#    my $words = $2;
#    @sep::metakeywords = $words;
#    $rest;
#}

sub do_cmd_noemailaddress {
    local ($_) = @_;
    @sep::emailaddress = "";
    shift (@sep::emailaddress);
    $_;
}

sub do_cmd_title {
    my $rest = shift;
    $rest =~ s/$next_pair_rx//o unless ($rest =~ s/$next_pair_pr_rx//o);
    $TITLE = $2 unless $TITLE;
    if ($sep::article) {
        join ('',"<H1 ALIGN=CENTER>",$2,"<\/H1>",$rest);
    } else {
        join ('',"<H1>","Short Note","<BR>",$2,"<\/H1>",$rest);
    }
}

sub do_cmd_chapter {
    my $rest = shift;
    $rest =~ s/$any_next_pair_rx//;
    $TITLE = $2 unless $TITLE;
    join ('',"<H1 ALIGN=LEFT>",$TITLE,"<\/H1>",$rest);
}

sub do_cmd_author {
    my $rest = shift; 
    $rest =~ s/$next_pair_rx//o unless ($rest =~ s/$next_pair_pr_rx//o);
    my $author = "<STRONG>" . $2;
    if ($sep::article) {
        $author = "<CENTER>" . $author; 
    } 
    if (@sep::emailaddress) {
	$author .= "<BR><BR>";
#        local ($br_id) = "email";
#        &process_footnote ($sep::emailaddress);
#        $author .= &make_href("$footfile#$br_id",$footnote_mark);
	foreach $email (@sep::emailaddress) {
            $email = join ('',"<A HREF=mailto:",$email,">",$email,"<\/A>");
        }
        $author .= join (', ',@sep::emailaddress);
    }
    if ($sep::article) {
        $author .= "<\/CENTER>";
    } 
    join ('',$author,"<\/STRONG>",$rest);
}

sub do_cmd_sepsection {
    my $text = shift;
    $text =~  s/$next_pair_pr_rx//o;
    my $section = $2;
    if ($section) {
	join ('',"<H2 align=center>",$section,"<\/H2>\n",$text);
    } else {
	$text;
    }
}

sub do_cmd_prefacesection {
    my $text = shift;
    $text =~  s/$next_pair_pr_rx//o;
    my $section = $2;
    if ($section) {
	join ('',"<HR><HR><H2 align=center>",$section,"<\/H2>\n",$text);
    } else {
	$text;
    }
}

sub do_cmd_boxit {
    my $text = shift;
    $text =~ s/$next_pair_pr_rx//o;
    local ($_) = $2;
    &extract_pure_text("liberal");
    join ("\n","<P>","<TABLE BORDER>","<TD>",$_,
	  "<\/TD>","<\/TABLE>","<\/P>\n",$text); 
}

sub do_cmd_ABS {
    my $abs = shift;
    $abs =~ s/$next_pair_pr_rx//o;
    local ($_) = $2;
    &extract_pure_text("liberal");
    if ($sep::article) {
	join ("\n","<CENTER><P>","<TABLE BORDER>","<TD>", 
	      "<H1 ALIGN=CENTER>ABSTRACT<\/H1>",$_,
	      "<\/TD>","<\/TABLE>","<\/P><\/CENTER>\n",$abs);
    } else {
	$abs;
    }
}

sub meta_information {
    local($_) = @_;

    # Cannot have nested HTML tags...
    do { s/<[^>]*>//g;
	 "<META NAME=\"description\" CONTENT=\"$_\">\n" .
	 "<META NAME=\"resource-type\" CONTENT=\"document\">\n" .
         "<META NAME=\"distribution\" CONTENT=\"global\">\n" } if $_;
#	 "<META NAME=\"keywords\" CONTENT=\"@sep::metakeywords\">\n" .

}



#sub do_cmd_APPENDIX {
#    local ($text) = @_; 
#    $text =~ s/$next_pair_pr_rx//o;
#    local ($app) = $2;
#    $latex_body .= &revert_to_raw_tex("\\APPENDIX{$app}\n");
#    $global{'eqn_number'} = 0;
#    "<H1 ALIGN=CENTER>APPENDIX $app<\/H1>\n" . $text;
#    $text;
#}

foreach $package ("label","input","cite","plot") {
    print ("Loading SEP's $package package...\n");
    require ("sep$package.pl");
}

&process_commands_wrap_deferred (<<_RAW_ARG_DEFERRED_CMDS_);
email # {}
_RAW_ARG_DEFERRED_CMDS_

1;                              # This must be the last line

