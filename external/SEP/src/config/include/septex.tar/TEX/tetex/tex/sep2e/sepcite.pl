package main;

#sub do_cmd_cite {
#    local($_) = @_;
#    s/$next_pair_pr_rx//o; 
#    $_;
#}

sub do_cmd_longcite {
    &do_cmd_cite;
}

sub do_cmd_shortcite {
    &do_cmd_citeyear;
}

sub do_cmd_reference {
    local ($_) = @_;
    s/$next_pair_pr_rx//o; 
    join ('','<UL><LI>',$2,'</LI></UL>',"\n",$_);
}

1;                              # This must be the last line
